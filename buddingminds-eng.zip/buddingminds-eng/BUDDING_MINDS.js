$("#file").on("change", function(event){
             $("#uploadButton").show();
    selectedfile = event.target.files[0];
             });
function uploadfile(){
    var messege = $('#text');
    var messege = $('text1');
    var filepath = $("#file")[0].value;
    var filename = $("#file")[0].files[0].name;
    var storage = firebase.storage();
    var ref = storage.ref();
    var imgRef = ref.child("budding_minds/"+filename);
    var uploadtask = imgRef.put($("#file")[0].files[0]);
    var txtRef = ref.child("budding_minds/" + "text-" + filename + ".txt");
    var instName = $("#instName").val();
    var desc = $("#instDesc").val();
    var uploadTask1 = txtRef.putString(instName + "\r\n" + desc);
    
    
   uploadtask.on('state_changed', function(snapshot){
       console.log(snapshot.toString());
   }, function(Error){
       console.log(Error.toString());
   }, function(){
       var downloadURL = uploadtask.snapshot.downloadURL;
       console.log(downloadURL);
   });
                
}